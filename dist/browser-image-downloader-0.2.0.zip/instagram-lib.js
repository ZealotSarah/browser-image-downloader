globalThis.InstagramImages = (() => {
  function imageUrl(raw) {
    try {
      const url = new URL(raw);
      if (url.protocol !== "https:" || !/(^|\.)(cdninstagram\.com|fbcdn\.net)$/i.test(url.hostname)) return null;
      return url.href;
    } catch {
      return null;
    }
  }

  function bestImageUrl(image) {
    const candidates = (image.srcset || "").split(",").map(entry => {
      const [url, width] = entry.trim().split(/\s+/);
      return { url: imageUrl(url), width: Number.parseInt(width, 10) || 0 };
    }).filter(entry => entry.url);
    candidates.sort((a, b) => b.width - a.width);
    return candidates[0]?.url || imageUrl(image.currentSrc || image.src);
  }

  function postIdFromUrl(raw) {
    try {
      const url = new URL(raw);
      if (url.hostname !== "www.instagram.com") return null;
      return url.pathname.match(/^\/p\/([A-Za-z0-9_-]+)(?:\/|$)/)?.[1] || null;
    } catch {
      return null;
    }
  }

  return { imageUrl, bestImageUrl, postIdFromUrl };
})();
